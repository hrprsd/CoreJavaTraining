
public class OperatorTest {
	public static void main(String[] args) {
		System.out.println(100+200+" value "+100+200 );
	}
}
