class CoreJava
{
	void myNewFunction()
	{
	}
	public static void main(String args[])
	{
		System.out.println("The code works fine");
	}
}