package db.ops;

public class DatabaseOperations {

	
	
}
