package myexceptions;

public class DepartmentAlreadyExistsException  extends RuntimeException {

	public DepartmentAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
