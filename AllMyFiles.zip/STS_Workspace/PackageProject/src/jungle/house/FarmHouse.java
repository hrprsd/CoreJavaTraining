package jungle.house;

public class FarmHouse {

}
