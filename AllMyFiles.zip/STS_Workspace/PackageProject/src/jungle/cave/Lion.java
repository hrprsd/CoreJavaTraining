package jungle.cave;

public class Lion {

}
