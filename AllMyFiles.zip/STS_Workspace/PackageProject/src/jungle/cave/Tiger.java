package jungle.cave;

public class Tiger {
				int defaultA = 100;
	private 	int privateB = 100;
	protected 	int protectedC = 100;
	public 		int publicD = 100;
	
	public void jump() {
		System.out.println("Tiger is jumping.....");
	}
	

}


