
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Line1");
		System.out.println("Line2");
		System.out.println("Line3");
		
		if(10>5)
			throw new RuntimeException("Something happened");
		
		System.out.println("Line4");
		System.out.println("Line5");
		System.out.println("Line6");
		if(10>5)
			throw new RuntimeException("Something happened");
		
		System.out.println("Line7");
		System.out.println("Line8");
		System.out.println("Line9");
		if(10>5)
			throw new RuntimeException("Something happened");
		
		System.out.println("Line10");
	}

}
