
public class DataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		
	//System.out.println("Byte "+ nurseryRollNumber);
	System.out.println("Size of Byte "+ Byte.SIZE);
	
	System.out.println("Size of Short "+ Short.SIZE);
	
	System.out.println("Size of Integer "+ Integer.SIZE);
	
	System.out.println("Size of Long "+ Long.SIZE);
	
	System.out.println("Size of Float "+ Float.SIZE);
	
	System.out.println("Size of Double "+ Double.SIZE);
	
	System.out.println("Size of Character "+ Character.SIZE);
	
	System.out.println("Size of Byte "+ Byte.SIZE);
	
	
	
	
	}

}
